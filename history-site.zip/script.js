document.addEventListener("DOMContentLoaded", () => {
  // Позначити активний пункт меню, порівнюючи базову назву файлу
  const links = document.querySelectorAll(".sidebar a");
  const current = window.location.pathname.split("/").pop() || "index.html";
  links.forEach(link => {
    const href = link.getAttribute("href");
    if (href === current) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });
});